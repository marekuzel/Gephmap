from gephmap import main

main()